SIMPLE VPN (front-end for WireGuard)
====================================
This app does not contain a VPN server or its own encryption. It gives you
one-click Connect/Disconnect on top of the official WireGuard client.

Setup
  1. Install WireGuard for Windows (free): https://www.wireguard.com/install/
     (the app has a button for this if it isn't found)
  2. Get a WireGuard .conf file from a VPN provider that offers them
     (e.g. Mullvad, Proton VPN, IVPN) or from your own server.
  3. Run SimpleVPN.exe (it asks for Administrator - needed to create the tunnel).
  4. Click "Import config...", choose your .conf, then click Connect.

Notes
  - Your config contains a private key. It is copied to
    %APPDATA%\SimpleVPN\ - don't share that folder.
  - Disconnect removes the tunnel service; Connect recreates it.
  - If SmartScreen warns about an unknown publisher, choose
    "More info" -> "Run anyway" (the exe is unsigned).
